let typed= new Typed(".teks", {
    strings: ["Seorang Mahasiswa", "Sedang Belajar Pemograman"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
